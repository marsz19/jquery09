<?php 
$nik = "MarsHostNew | HOSTING";
$sender = "Admin@marshostnew.com";
?>